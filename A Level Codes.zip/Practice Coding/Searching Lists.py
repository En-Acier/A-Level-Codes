#Setting up a list
name = ["Alan", "Barry","Chris", "Dave"]
#Taking inputs
search = input("Please input the name of the student you wish to get the record number for")
#Getting the length of the list
length = len(name)
#Getting the result with a "while" loop
y = 0
while y <= length:
    if search in name:
        print("This student's number is",y+1)
        y = 99
    else:
        y = y + 1
#Getting the result with a "for" loop
for i in range(length):
    if search == name[i]:
        print("This student's number is", i+1, "but this time it's more accurate due to using a different kind of loop")