a = int(input("Please enter a number"))
for i in range(4):
    b = int(input("Please enter another number"))
    if a < b:
        a = b
print(a, "is the largest number")

