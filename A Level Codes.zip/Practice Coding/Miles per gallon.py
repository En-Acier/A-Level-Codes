RATE = 0.22
oldMileage = int(input("Please input the mileage of your car the last time the tank was filled"))
newMileage = int(input("Please input the mileage of your car now"))
miles = newMileage - oldMileage
litres = int(input("Please input the amount of litres your car can hold"))
gallons = litres * RATE
mpg = miles / gallons
print("Your miles per gallon is...",mpg)