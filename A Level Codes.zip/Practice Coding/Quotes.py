#Input

no = input("Please enter a number between one and five")

#validity
x = 1
while x == 1:
    #Evaluating
    if no.lower() == "1" or no.lower() == "one":
        print("Hey, now, you're an All Star, get your game on, go play. Hey, now, you're a Rock Star, get the show on, get paid. And all that glitters is gold. Only shooting stars break the mold - Smash Mouth, 2001")
        x = 0
    elif no.lower() == "2" or no.lower() == "two":
        print("Ask for nothing & you shall receive it... In abundance! - Dr Frank N Furter, 1975")
        x = 0
    elif no.lower() == "3" or no.lower() == "three":
        print("We all make choices in life, but in the end our choices make us - Andrew Ryan, 2007")
        x = 0
    elif no.lower() == "4" or no.lower() == "four":
        print("Never forget what you are, for surely the world will not. Make it your strength. Then it can never be your weakness. Armour yourself in it, and it will never be used to hurt you - Tyrion Lannister, 1996")
        x = 0
    elif no.lower() == "5" or no.lower() == "five":
        print("Courage isn't just a tap you can turn on and off whenever you want it to. Courage isn't a permanence. Courage is a tenious and fickle thing; courage and cowardice exist in every man... Get over it! - Jack Kelso, 2011")
        x = 0
    else:
        no = input("Please enter a number between one and five")







