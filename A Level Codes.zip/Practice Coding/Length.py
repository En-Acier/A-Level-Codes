#INPUT name

name = input("What is your name?")

#find length

name = len(name)

#OUTPUT name

print("That has",name,"letters!")