row = input("Would you like to print a row or a rectangle of stars?")
x = "*"
if row.lower() == "row":
    #printing one row
    y = int(input("How many stars would you like to print?"))
    print(y * x)
elif row.lower() == "rectangle":
    #printing a rectangle
    y = int(input("How many stars would you like in one row of a rectangle?"))
    z = int(input("How many rows would you like in that rectangle?"))
    for i in range(z):
        print(y * x)
else:
    print("Sorry but what you typed was invalid, please try again")

for i in range(1):
    print("This is the obligatory loop")