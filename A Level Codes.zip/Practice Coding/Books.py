#INPUT number of students

students = int(input("Please enter the number of students"))

#INPUT number of books

books = int(input("Please enter the number of books available"))

#Calculate number of books per student

bps = books // students

#OUTPUT

print("There are",bps,"books per student")
