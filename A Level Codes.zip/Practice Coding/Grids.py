import random

grid = [
        ["","","",],
        ["","","",],
        ["","",""],
        ]

for x in range(3):
    for y in range(3):
        grid[x][y] = 0

x = random.randint(0,2)
y = random.randint(0,2)
grid[x][y] = 1

print(grid)