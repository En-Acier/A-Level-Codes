park = [
        ["empty","empty","empty","empty", "empty", "empty"],
        ["empty","empty","empty","empty", "empty", "empty"],
        ["empty","empty","empty","empty", "empty", "empty"],
        ["empty","empty","empty","empty", "empty", "empty"],
        ["empty","empty","empty","empty", "empty", "empty"],
        ["empty","empty","empty","empty", "empty", "empty"],
        ["empty","empty","empty","empty", "empty", "empty"],
        ["empty","empty","empty","empty", "empty", "empty"],
        ["empty","empty","empty","empty", "empty", "empty"],
        ["empty","empty","empty","empty", "empty", "empty"],
        ]
row = int(input("Which row?"))
column = int(input("Which column?"))
park[row][column] = input("What is your registration?")
print(park)
