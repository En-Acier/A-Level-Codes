Outlet1 = [10,12,15,10]
Outlet2 = [5,8,3,6]
Outlet3 = [10,12,15,10]
for i in range(4):
    total = Outlet1[i] + Outlet2[i] + Outlet3[i]
    print("The total for quarter", i + 1,"is", total)