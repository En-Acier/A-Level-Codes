numbers = [0,0,0,0,0,0,]

total = 0

for i in range(6):
    numbers[i] = int(input("Please enter a number"))
    total = total + numbers[i]

for i in reversed(numbers):
    print(i)

average = total / 6
print("Average = ", average)

i = 5
while i >= 0:
    print(numbers[i])
    i = i - 1

