volume = int(input("Please input the volume of one pot of paint:"))
width = int(input("Please input the width of the wall you wish to paint:"))
length = int(input("Please input the length of the wall you wish to paint:"))
area = width * length
pots = float(area / volume)
print("You will need",pots,"pots of paint")