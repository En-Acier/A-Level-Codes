num = int(input("Please input a number inbetween 1 and 12"))
if num >= 1 and num <= 12:
    for i in range (13):
        print(i, "x", num, "=", num * i)
else:
    print("That number was invalid, please try again")