#Inputs

a = float(input("Please enter a decimal number"))
b = float(input("Please enter another decimal number"))

#A selection occurs to decide on the output

if a > b:
    print(a, "is greater than", b)
elif b > a:
    print(a, "is less than", b)
elif a == b:
    print("These numbers are the same")
else:
    print("The numbers you have entered are invalid, please try again")
