def makeCarPark():
    for i in range(5):
        grid.append(["N/A","N/A","N/A","N/A","N/A",])
def menu():
    print("Press 1 to display the car park")
    print("Press 2 to park a car")
    print("Press 3 to automatically park a car")
    print("Press 4 to unpark a car")
    print("Press 5 to exit")
    choice = input("Enter your choice here...")
    return(choice)
def parkCar():
    reg = input("What is your vehicle registration?")
    x = int(input("What is the x co-ordinate?"))
    y = int(input("What is the y co-ordinate?"))
    grid[x][y] = reg
def autoPark():
    i = 0
    j = 0
    parked = False
    reg = input("What is your vehicle registration?")
    while i < 5 and parked!= True:
        while j < 5 and parked!= True:
            if grid[i][j] == "N/A":
                grid[i][j] = reg
                parked = True
            j = j + 1
        i = i + 1

def unpark():
    x = int(input("What is the x co-ordinate?"))
    y = int(input("What is the y co-ordinate?"))
    grid[x][y] = "N/A"
grid = []
choice = 0
makeCarPark()
while choice != "5":
    choice = menu()
    if choice == "1":
        for i in range(len(grid)):
            print(grid[i])
    elif choice == "2":
        parkCar()
        for i in range(len(grid)):
            print(grid[i])
    elif choice == "3":
        autoPark()
    elif choice == "4":
        unpark()
    elif choice == "5":
        print("Ending program")
    else:
        print("Sorry, but what you pressed was not valid. Please try again")