rows = [["X", "X", "X," "X"], ["X", "X", "X," "X"], ["X", "X", "X," "X"], ["X", "X", "X," "X"], ["X", "X", "X," "X"], ["X", "X", "X," "X"]]
def displaygrid():



x = input("Please input the first co-ordinate")
y = input("Please input the second co-ordinate")

