#Taking inputs
no = int(input("Please enter a number"))
if no >= 1 and no <= 10:
    while no <= 20:
        print(no)
        no = no + 2
elif no > 10 and no < 100:
    while no <= 100:
        print(no)
        no = no + 4
else:
    print("That number is invalid, please try again")
