year = int(input("What is the current year?"))
birth = int(input("What is your year of birth?"))
age = year - birth
day = input("What day would you like to play?")
if len(day) > 3:
    print("Please only input the first three letters of the day you wish to play. (E.g. Mon, Tue, Wed,)")
elif day.lower() == "mon" or day.lower() == "thu" or day.lower() == "sun" and age >= 66:
    print("Your ticket price is £9.43")
else:
    print("Your ticket price is £11.50")