#Task one (short enough to be paired
for i in range(25):
    print("AS computing is cool")


message = input("Please input a message")
x = int(input("How many times should I repeat that message"))
for i in range(x):
    print(message)