#Inputs

percent = float(input("Please enter the percentage score"))
if percent < 40 :
    print("This is a fail")
elif percent < 50 and percent > 40:
    print("This is a D")
elif percent < 60 and percent > 50:
    print("This is a C")
elif percent < 70 and percent > 60:
    print("This is a B")
elif percent < 85 and percent > 70:
    print("This is an A")
elif percent <= 85 and percent >= 100:
    print("This is an A*")
else:
    print("The percentage score you entered was invalid, please try again")
