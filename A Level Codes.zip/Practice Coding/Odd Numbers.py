x = 0
for i in range(100):
    if i % 2 == 1:
        x = x + i
print(x)
