x = input("Please input a sentence")
e = ["e"]
count = 0
length = len(x)
for i in range(length):
    if x[i] in e:
        count = count + 1
print("The letter E occurred", count, "times!")