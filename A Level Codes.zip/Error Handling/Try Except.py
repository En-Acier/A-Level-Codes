score = input("Please enter the next score:")
try:
    score = int(score)
except:
    print("That was not a number!")