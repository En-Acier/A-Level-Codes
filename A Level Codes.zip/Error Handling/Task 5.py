names = ["Belinda", "Gerri", "Tom"]
for i in range(len(names)):
    print(names[i])
print("Program continuing...")
